const INVALID_CHARS_REGEXP = /[^\x20-\x7E]/;

export { INVALID_CHARS_REGEXP };
